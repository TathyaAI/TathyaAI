// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "insertDivOnSelection") {
      const selectedText = window.getSelection().toString().trim();
      if (selectedText !== "") {
        // Get the bounding box of the selected text
        const range = window.getSelection().getRangeAt(0);
        const boundingBox = range.getBoundingClientRect();
  
        // Create a new div element to display the text
        const newDiv = document.createElement("div");
        newDiv.textContent = message.text;
        newDiv.style.position = "absolute";
        newDiv.style.top = `${boundingBox.top}px`;
        newDiv.style.left = `${boundingBox.right}px`;
        newDiv.style.backgroundColor = "lightgray";
        newDiv.style.padding = "5px";
        newDiv.style.border = "1px solid gray";
        newDiv.style.borderRadius = "5px";
  
        // Append the div to the document body
        document.body.appendChild(newDiv);
      }
    }
  });