// Function to handle context menu item click
function onMenuItemClick(info, tab) {
    if (info.menuItemId === "factCheckSelection") {
      const correct = Math.random() < 0.5;
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: insertDivOnSelection,
        args: [correct],
      });
    }
  }
  
  // Injected function to insert a div just below the selected text
  function insertDivOnSelection(correct) {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText !== "") {
      // Create a new <style> element
      const styleElement = document.createElement('style');

      // Define your CSS rules as a string
      const cssRules = `
        .component-1,
        .component-1 * {
          box-sizing: border-box;
        }
        .component-1 {
          width: 345px;
          height: 48px;
          position: relative;
        }
        .alert {
          background: var(--tertiary, #eef1f4);
          border-radius: 6px;
          padding: 12px 16px 12px 16px;
          display: flex;
          flex-direction: row;
          gap: 12px;
          align-items: center;
          justify-content: flex-start;
          width: 345px;
          height: 48px;
          position: absolute;
          left: 0px;
          top: 0px;
        }
        .check-circle {
          flex-shrink: 0;
          width: 24px;
          height: 24px;
          position: relative;
          overflow: hidden;
        }
        .title {
          color: var(--primary, #545f71);
          text-align: left;
          font: var(--body, 400 16px/22px "Inter", sans-serif);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: flex-start;
        }
        .ban {
          position: absolute;
          left: 16px;
          top: 12px;
          overflow: visible;
        }
      `;

      // Set the CSS text of the <style> element to your rules
      styleElement.textContent = cssRules;

      // Add the <style> element to the document's <head> or another suitable location
      document.head.appendChild(styleElement);

      // Get the bounding box of the selected text
      const range = window.getSelection().getRangeAt(0);
      const boundingBox = range.getBoundingClientRect();
  
      // Create a new div element to display the text
      const newDiv = document.createElement("div");
      newDiv.style.all = "initial"
      newDiv.id = "factCheckDiv";
      // newDiv.textContent = text;
      newDiv.style.display = "block"
      newDiv.style.position = "absolute";
      newDiv.style.top = `${boundingBox.bottom + window.scrollY + 20}px`;
      newDiv.style.left = `${boundingBox.left + window.scrollX}px`;
      newDiv.style.width = `240px`;
      newDiv.style.height = `auto`;
      newDiv.style.zIndex = "99999";
      
      // Create the main container element with class "component-1"
      newDiv.classList.add('component-1');

      // Create the "alert" div with class "alert"
      const alertDiv = document.createElement('div');
      alertDiv.classList.add('alert');

      // Create the "check-circle" div with class "check-circle"
      const checkCircleDiv = document.createElement('div');
      checkCircleDiv.classList.add('check-circle');

      // Create the "title" div with class "title" and set its text content
      const titleDiv = document.createElement('div');
      titleDiv.classList.add('title');
      if (!correct) {
        titleDiv.textContent = 'The claims in the selection are false';
      } else {
        titleDiv.textContent = 'The claims in the selection are true';
      }

      // Append the "check-circle" and "title" divs to the "alert" div
      alertDiv.appendChild(checkCircleDiv);
      alertDiv.appendChild(titleDiv);

      // Create the SVG element with class "ban" and set its attributes
      const svgElement = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svgElement.classList.add('ban');
      svgElement.setAttribute('width', '24');
      svgElement.setAttribute('height', '24');
      svgElement.setAttribute('viewBox', '0 0 24 24');
      svgElement.setAttribute('fill', 'none');
      svgElement.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

      // Create the path element inside the SVG
      const pathElement = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      if (!correct) {
        pathElement.setAttribute('d', 'M18.364 18.364C21.8787 14.8492 21.8787 9.15076 18.364 5.63604C14.8492 2.12132 9.15076 2.12132 5.63604 5.63604M18.364 18.364C14.8492 21.8787 9.15076 21.8787 5.63604 18.364C2.12132 14.8492 2.12132 9.15076 5.63604 5.63604M18.364 18.364L5.63604 5.63604');
        pathElement.setAttribute('stroke', '#D72222');
      } else {
        pathElement.setAttribute('d', 'M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z');
        pathElement.setAttribute('stroke', '#45A81A');
      }
      
      pathElement.setAttribute('stroke-width', '2');
      pathElement.setAttribute('stroke-linecap', 'round');
      pathElement.setAttribute('stroke-linejoin', 'round');

      // Append the path element to the SVG element
      svgElement.appendChild(pathElement);

      // Append the "alert" div and SVG element to the main container
      newDiv.appendChild(alertDiv);
      newDiv.appendChild(svgElement);


      // Add a click listener to the div to remove it on click
      newDiv.addEventListener("click", () => {
        newDiv.style.opacity = "0";
        newDiv.style.transform = "translateY(-100%)";
        setTimeout(() => {
          newDiv.remove();
        }, 300);
      });  

      // Add a mouse scroll listener to the div to remove it on scroll
      newDiv.addEventListener("wheel", () => {
        newDiv.style.opacity = "0";
        newDiv.style.transform = "translateY(-100%)";
        setTimeout(() => {
          newDiv.remove();
        }, 300);
      });

    
      // Append the containing div of the selected text
      // const selectionContainer = range.commonAncestorContainer.parentNode;
      const selectionContainer = document.body;
      selectionContainer.appendChild(newDiv);
    }
  }
  
  // Create a context menu item
  chrome.contextMenus.create({
    id: "factCheckSelection",
    title: "Fact-check this selection",
    contexts: ["selection"],
  });
  
  // Add a listener to handle context menu clicks
  chrome.contextMenus.onClicked.addListener(onMenuItemClick);